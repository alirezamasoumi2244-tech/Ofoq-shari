# تغییرات نسخه ۲.۱.۱ — افق شرعی

## ✅ تبلیغات تپسل کاملاً فعال شد (بدون هیچ کار دستی)

### اشکالی که برطرف شد
در نسخه ۲.۱.۰ وابستگی SDK تپسل با **گروه اشتباه** در Gradle نوشته شده بود
(`ir.tapsell:tapsell`). آن ماژول فقط پخش‌کننده ویدیو (billboard) است و
کلاس `ir.tapsell.mediation.Tapsell`، متدهای بنر و محل خواندن App Key را
ندارد؛ یعنی پروژه یا کامپایل نمی‌شد یا تبلیغ هرگز فعال نمی‌شد.

**گروه درست که با بایت‌کد AAR نسخه ۱.۳.۰ در Maven Central اعتبارسنجی شد:**

```gradle
implementation "ir.tapsell.mediation:tapsell:1.3.0"          // کلاس Tapsell + banner API + خواندن App Key
implementation "ir.tapsell.mediation.adapter:legacy:1.3.0"   // سازگاری با تپسل قدیمی
```

همین AAR خودش این متادیتا را در مانیفست نهایی تزریق می‌کند و مقدارش از
placeholder گرفته می‌شود؛ پس نیازی به اضافه‌کردن دستی `<meta-data>` نیست:

```xml
<meta-data android:name="ir.tapsell.mediation.APPLICATION_KEY"
           android:value="${TapsellMediationAppKey}" />
```

### App Key شما ثبت شد
شناسه اپلیکیشن (App Key) که فرستادید، داخل `tools/patch_android.py` در خط
`TAPSELL_APP_KEY` ثبت شده و از این به بعد به‌طور خودکار به پروژه اندروید تزریق
می‌شود:

```
mkerkacpddbnttkiceabqptdpissipciqmojhhdkceocgbfkcchppfhpmhlemgafodclej
```

۴ شناسه فضای تبلیغاتی (Zone IDs) هم مطابق قبل در `native/kotlin/AzanAds.kt`
هستند و بنر بین آن‌ها می‌چرخد:

| # | Zone ID |
|---|---|
| ۱ | `6b0071167597d07cbabd6e9e` |
| ۲ | `6b00715f728e2256843b0caf` |
| ۳ | `6b007174728e2256843b0cb0` |
| ۴ | `6b0071897597d07cbabd6e9f` |

### مهاجرت خودکار
اگر قبلاً `setup.sh` را با نسخه ۲.۱.۰ اجرا کرده‌اید و پوشه `android/` دارید،
یک‌بار دیگر همین کار را بکنید؛ اسکریپت پچ خودش:
- مقدار خالی `TapsellMediationAppKey` را با کلید واقعی پر می‌کند؛
- وابستگی قدیمی `ir.tapsell:tapsell` را به گروه درست `ir.tapsell.mediation:tapsell` تبدیل می‌کند.

### رفتار بنر (مطابق قبل)
- بنر ۳۲۰×۵۰ فقط در **بخش پایینی صفحه اذان (خانه)**؛ WebView به‌اندازه بنر جمع می‌شود تا چیزی پوشانده نشود.
- در بقیه صفحات و حین پخش اذان و حین راه‌اندازی اولیه، بنر پنهان است.
- چرخش بین ۴ فضا: اگر فضایی تبلیغ نداشت، فضای بعدی امتحان می‌شود؛ هیچ‌کدام پر نشد، ۳۰ ثانیه بعد تلاش مجدد.
- تازه‌سازی هر ۶۰ ثانیه با فضای بعدی (بازدید بیشتر، درآمد بیشتر).
- همه کال‌های SDK داخل try/catch هستند؛ قطع اینترنت یا تبلیغ خراب برنامه را نمی‌بندد.

## نحوه ساخت APK
مثل قبل: `bash setup.sh` و سپس `./build-apk.sh` (یا همان GitHub Action).
هیچ تنظیم دستی دیگری لازم نیست — کلید و SDK همه خودکار هستند.
