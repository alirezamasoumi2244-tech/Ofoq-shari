# تغییرات نسخه ۲.۱.۳ — افق شرعی

## ✅ رفع خطای بیلد: «resource drawable/wgt_bg not found» و مشابه‌ها (AAPT)

### خطا چه بود؟
بعد از رفع خطای compileSdk در نسخه ۲.۱.۲، بیلد این‌بار جلوتر رفت و روی لینک
منابع (AAPT) شکست خورد:

```
AAPT: error: resource drawable/wgt_bg not found
AAPT: error: resource drawable/wgt_accent_bar not found
AAPT: error: resource drawable/wgt_chip not found
AAPT: error: resource drawable/wgt_progress not found
```

### علت
لایه‌های XML ویجت‌های صفحه اصلی (۷ ویجت افق شرعی) به ۵ شکل پس‌زمینه ارجاع
می‌دهند (`wgt_bg`، `wgt_bg_compact`، `wgt_chip`، `wgt_accent_bar`،
`wgt_progress`) که داخل `native/res/drawable/` هستند — ولی
`tools/patch_android.py` فقط پوشه‌های `layout` و `xml` را کپی می‌کرد و پوشه
`drawable` را جا انداخته بود. این اشکال از نسخه ویجت‌ها وجود داشت، ولی تا
حالا پنهان بود چون بیلد قبل از رسیدن به مرحله منابع در `checkAarMetadata`
می‌شکست.

### راه‌حل — یک خط، کاملاً خودکار
حالا پچ پوشه `drawable` را هم کپی می‌کند؛ یعنی هر ۵ شکل کنار لایه‌ها در
`app/src/main/res/drawable/` قرار می‌گیرد و AAPT همه را می‌بیند.

### تأیید
- یک اسکریپت کنترل جدا نوشته شد که **هر ۱۳ ارجاع منبع** (`@drawable/...`،
  `@layout/...`، `@xml/...` و …) را با منابع موجود مقایسه می‌کند: همه پیدا می‌شوند.
- اجرای تکراری پچ هم امن است (فایل‌ها فقط بازنویسی می‌شوند، دوباره‌سازی نمی‌شوند).

### چیز دیگری تغییر کرد؟
خیر — App Key تپسل، ۴ فضای تبلیغاتی، ارتقای AGP 8.7.3 / Gradle 8.9 /
compileSdk 35 (از نسخه ۲.۱.۲) و کد برنامه همه دست‌نخورده ماندند.
