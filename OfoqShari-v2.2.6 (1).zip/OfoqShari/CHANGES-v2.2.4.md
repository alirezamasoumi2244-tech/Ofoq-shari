# تغییرات نسخه ۲.۲.۴ — رفع hang شدن SDK تپسل

## از گزارش تشخیص (لمس طولانی)

```
sdkInit: "waiting"
appKey: present
azan slots: visible=true, requesting=true, attempts=0
zoneKinds: همه unknown
```

یعنی:
- کلید تپسل در برنامه هست
- اسلات‌های صفحه اذان پیدا شده‌اند
- ولی SDK هرگز «آماده» اعلام نشده و درخواست‌ها بدون پاسخ مانده‌اند

## علت

ContentProvider تپسل معمولاً هنگام استارت اپ auto-init می‌شود. اگر `setInitializationListener` **بعد از** اتمام init ست شود، کالبک `onInitializationComplete` دیگر صدا زده نمی‌شود → `sdkReady` همیشه false می‌ماند و بعضی درخواست‌ها hang می‌کنند (`requesting: true` ابدی).

## اصلاحات

1. **MainActivity** — listener همان اول `onCreate` ست می‌شود.
2. **forceReadyIfWaiting** — اگر بعد از ۴ و ۱۰ ثانیه هنوز waiting بود، ready فرض می‌شود و درخواست‌ها از نو زده می‌شوند.
3. **timeout ۱۵ ثانیه‌ای** برای هر request — اگر onSuccess/onFailure نیامد، به‌عنوان failure پردازش و سراغ فضا/نوع بعدی می‌رود.
4. با رسیدن کالبک واقعی init، درخواست‌های معلق دوباره kick می‌شوند.

## نسخه

**2.2.4**

## تست

1. APK قبلی را پاک کن، بیلد ۲.۲.۴ را نصب کن.
2. چند ثانیه صبر کن روی صفحه خانه / صفحه اذان.
3. باید یا تبلیغ بیاید، یا پیام قرمز خطای واقعی تپسل (مثلاً no fill).
4. لمس طولانی → در JSON باید `"sdkInit": "complete"` باشد (نه waiting).
5. لاگ: `adb logcat -s AzanAds`
