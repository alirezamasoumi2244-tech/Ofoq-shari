# تغییرات نسخه ۲.۱.۲ — افق شرعی

## ✅ رفع خطای بیلد: «compileSdk 35 لازم است» (checkAarMetadata)

### خطا چه بود؟
روی GitHub Actions (و هر جای دیگر) بیلد با این پیام شکست می‌خورد:

```
Execution failed for task ':app:checkReleaseAarMetadata'.
> Dependency 'androidx.work:work-runtime-ktx:2.10.5' requires libraries and
  applications that depend on it to compile against version 35 or later of
  the Android APIs. :app is currently compiled against android-34.
> Also, the maximum recommended compile SDK version for Android Gradle
  plugin 8.2.1 is 34.
```

### علت
SDK تپسل (نسخه ۱.۳.۰) به `androidx.work:work-runtime(-ktx) 2.10.5` وابسته است و
این کتابخانه فقط وقتی کامپایل می‌شود که **compileSdk پروژه ۳۵ یا بالاتر** باشد.
قالب Capacitor 6 اما پروژه اندروید را با **compileSdk 34** و
**Android Gradle Plugin 8.2.1** (که حداکثر compileSdk مجازش ۳۴ است) می‌سازد.

### راه‌حل — کاملاً خودکار
`tools/patch_android.py` از این نسخه یک گام جدید (گام ۷) دارد که هنگام اجرای
`setup.sh` یا Action به‌طور خودکار:

| مورد | قبل | بعد |
|---|---|---|
| Android Gradle Plugin | 8.2.1 | **8.7.3** |
| Gradle (wrapper) | 8.2.1 | **8.9** |
| compileSdk | 34 | **35** |
| targetSdk | 34 | 34 (بدون تغییر — رفتار برنامه عیناً قبلی) |

- اگر پروژه از قبل جدیدتر باشد، چیزی عوض نمی‌شود (اجرای تکراری امن است).
- اگر `variables.gradle` نباشد، `compileSdk` مستقیماً در `app/build.gradle` اصلاح می‌شود.
- در GitHub Actions هیچ تغییری لازم نیست؛ پلتفرم android-35 به‌طور خودکار با مجوزهای پذیرفته‌شده دانلود می‌شود.
- در Android Studio بعد از باز کردن پروژه یک‌بار **Gradle Sync** بزنید تا Gradle 8.9 دانلود شود.

### چیز دیگری تغییر کرد؟
خیر — کد برنامه، تبلیغات تپسل (App Key و ۴ فضای تبلیغاتی از نسخه ۲.۱.۱) و
رفتار اذان/قبله همه دست‌نخورده ماند. فقط ابزارهای بیلد ارتقا یافت.
